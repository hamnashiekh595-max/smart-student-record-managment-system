package AVLTree;

import java.util.Scanner;

public class Main {

	 public static void main(String[] args) {
	     Scanner sc = new Scanner(System.in);
	     AVLTree tree = new AVLTree();
	     Node root = null;

	     while (true) {
	         System.out.println("\n===== AVL Student System =====");
	         System.out.println("1. Add Student");
	         System.out.println("2. Search Student");
	         System.out.println("3. Delete Student");
	         System.out.println("4. Display All Students");
	         System.out.println("5. Exit");
	         System.out.print("Choose: ");

	         int choice = sc.nextInt();

	         switch (choice) {

	             case 1:
	                 System.out.print("Enter ID: ");
	                 int id = sc.nextInt();
	                 sc.nextLine();
	                 System.out.print("Enter Name: ");
	                 String name = sc.nextLine();
	                 System.out.print("Enter CGPA: ");
	                 double cgpa = sc.nextDouble();
	                 root = tree.insert(root, id, name, cgpa);
	                 System.out.println("Student Added Successfully!");
	                 break;

	             case 2:
	                 System.out.print("Enter ID to search: ");
	                 int sid = sc.nextInt();
	                 Node found = tree.search(root, sid);
	                 if (found != null) {
	                     System.out.println("Found → ID: " + found.id + ", Name: " + found.name + ", CGPA: " + found.cgpa);
	                 } else {
	                     System.out.println("Student Not Found!");
	                 }
	                 break;

	             case 3:
	                 System.out.print("Enter ID to delete: ");
	                 int did = sc.nextInt();
	                 root = tree.deleteNode(root, did);
	                 System.out.println("Deleted Successfully!");
	                 break;

	             case 4:
	                 System.out.println("\nStudent Records:");
	                 tree.inorder(root);
	                 break;

	             case 5:
	                 System.out.println("Program Ended.");
	                 System.exit(0);

	             default:
	                 System.out.println("Invalid Choice!");
	         }
	     }
	 }
	}
